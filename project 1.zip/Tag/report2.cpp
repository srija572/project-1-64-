#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>
#include <algorithm>
#include <cctype>
#include <set>
#include <cmath>

const int NUM_BOOKS = 64; // Number of books

// Helper function to clean and normalize text
std::string cleanText(const std::string &text) {
    std::string result;
    for (char c : text) {
        if (isalnum(c)) {
            result += toupper(c); // Convert to uppercase and keep alphanumeric characters
        } else {
            result += ' '; // Replace non-alphanumeric characters with space
        }
    }
    return result;
}

// Function to remove common words from a set of common words
std::string removeCommonWords(const std::string &text, const std::set<std::string> &commonWords) {
    std::istringstream iss(text);
    std::string word, result;
    while (iss >> word) {
        if (commonWords.find(word) == commonWords.end()) { // Keep the word if it's not common
            result += word + " ";
        }
    }
    return result;
}

// Function to calculate word frequencies
std::unordered_map<std::string, int> calculateWordFrequencies(const std::string &text) {
    std::unordered_map<std::string, int> wordCount;
    std::istringstream iss(text);
    std::string word;
    while (iss >> word) {
        wordCount[word]++;
    }
    return wordCount;
}
// Function to normalize word frequencies
std::unordered_map<std::string, double> normalizeFrequencies(const std::unordered_map<std::string, int> &wordCount, int totalWords) {
    std::unordered_map<std::string, double> normalizedFreq;
    for (const auto &pair : wordCount) {
        normalizedFreq[pair.first] = static_cast<double>(pair.second) / totalWords;
    }
    return normalizedFreq;
}

// Function to calculate similarity between two books
double calculateSimilarity(const std::unordered_map<std::string, double> &freq1, const std::unordered_map<std::string, double> &freq2) {
    double similarity = 0.0;
    for (const auto &wordFreq : freq1) {
        if (freq2.find(wordFreq.first) != freq2.end()) {
            similarity += std::min(wordFreq.second, freq2.at(wordFreq.first)); // Sum of normalized frequencies for common words
        }
    }
    return similarity;
}

// Main function to process books and calculate similarity matrix
int main() {
    std::set<std::string> commonWords = {"A", "AND", "AN", "OF", "IN", "THE"};

 std::vector<std::string> bookFiles = {
    "C:\\Users\\AJEYA\\Documents\\Tag\\Cats by Moncrif.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Foxes Book of Martyrs Part 1.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Foxes Book of Martyrs Part 2.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Foxes Book of Martyrs Part 3.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Foxes Book of Martyrs Part 4.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Foxes Book of Martyrs Part 5.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Foxes Book of Martyrs Part 6.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Gerards Herbal Vol. 1.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Gerards Herbal Vol. 2.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Gerard's Herbal Vol. 3.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Gerards Herbal Vol.4.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Gil Blas.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Gossip in a Library.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Hudibras.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\King of the Beggars.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Knocknagow.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Les Chats par Moncrif.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Lives and Anecdotes of Misers.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Love and Madness - Herbert Croft.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Memoirs of Laetitia Pilkington V 1.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Memoirs of Laetitia Pilkington V 2.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Memoirs of Laetitia Pilkington V 3.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Memoirs of Mrs Margaret Leeson - Peg Plunkett.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Monro his Expedition.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Mrs Beetons Book of Household Management.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Out of the Hurly-Burly.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Percys Reliques.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Pompey The Little.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Radical Pamphlets from the English Civil War.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Scepsis Scientifica.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Anatomy of Melancholy Part 1.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Anatomy of Melancholy Part 2.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Anatomy of Melancholy Part 3.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Complete Cony-catching.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Consolation of Philosophy.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Covent Garden Calendar.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Devil on Two Sticks.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Diary of a Lover of Literature.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The History Of Ireland - Geoffrey Keating.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The History of the Human Heart.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Ingoldsby Legends.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Life of Beau Nash.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Life of John Buncle by Thomas Amory.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Life of King Richard III.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Life of Pico della Mirandola.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Martyrdom of Man.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Masterpiece of Aristotle.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Memoirs of Count Boruwlaski.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Metamorphosis of Ajax.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Newgate Calendar - Supplement 3.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Newgate Calendar Supplement 2.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Newgate Calendar Supplement.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Newgate Calendar V 1.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Newgate Calendar V 2.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Newgate Calendar V 3.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Newgate Calendar V 4.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Newgate Calendar V 5.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Newgate Calendar V 6.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Poems of Ossian.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Poetical Works of John Skelton.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Protestant Reformation.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Real Story of John Carteret Pilkington.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Rowley Poems.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Silver Fox.txt"
};



    std::vector<std::unordered_map<std::string, double>> normalizedFrequencies(NUM_BOOKS);
    std::vector<int> totalWords(NUM_BOOKS);

    // Process each book
    for (int i = 0; i < NUM_BOOKS; i++) {
        std::ifstream file(bookFiles[i]);
        if (!file.is_open()) {
            std::cerr << "Error: Could not open " << bookFiles[i] << std::endl;
            return 1;
        }

        std::ostringstream buffer;
        buffer << file.rdbuf(); // Read file into buffer
        std::string text = buffer.str();

        // Clean, normalize, and remove common words
        text = cleanText(text);
        text = removeCommonWords(text, commonWords);

        // Calculate word frequencies
        auto wordFrequencies = calculateWordFrequencies(text);
        totalWords[i] = text.size();

        // Normalize word frequencies
        normalizedFrequencies[i] = normalizeFrequencies(wordFrequencies, totalWords[i]);
    }

    // Create a 64x64 similarity matrix
    double similarityMatrix[NUM_BOOKS][NUM_BOOKS] = {0};

    // Calculate similarity index for each pair of books
    for (int i = 0; i < NUM_BOOKS; i++) {
        for (int j = i + 1; j < NUM_BOOKS; j++) {
            similarityMatrix[i][j] = calculateSimilarity(normalizedFrequencies[i], normalizedFrequencies[j]);
        }
    }

    // Find the top 10 most similar pairs
    std::vector<std::tuple<int, int, double>> topSimilarities;
    for (int i = 0; i < NUM_BOOKS; i++) {
        for (int j = i + 1; j < NUM_BOOKS; j++) {
            topSimilarities.push_back({i, j, similarityMatrix[i][j]});
        }
    }

    // Sort the similarities in descending order
    std::sort(topSimilarities.begin(), topSimilarities.end(), [](const auto &a, const auto &b) {
        return std::get<2>(a) > std::get<2>(b);
    });

    // Output the top 10 similar pairs
    std::cout << "Top 10 similar pairs of books:" << std::endl;
    for (int i = 0; i < 10; i++) {
        auto [book1, book2, similarity] = topSimilarities[i];
        std::cout << "Book " << book1 + 1 << " and Book " << book2 + 1 << " - Similarity: " << similarity << std::endl;
    }

    return 0;
}

