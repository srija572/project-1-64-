#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <unordered_map>
#include <vector>
#include <algorithm>
#include <cctype>
#include <set>

// Helper function to clean and normalize text
std::string cleanText(const std::string &text) {
    std::string result;
    for (char c : text) {
        if (isalnum(c)) {
            result += toupper(c); // Convert to uppercase and keep alphanumeric characters
        } else {
            result += ' '; // Replace non-alphanumeric characters with space
        }
    }
    return result;
}

// Function to remove common words from a set of common words
std::string removeCommonWords(const std::string &text, const std::set<std::string> &commonWords) {
    std::istringstream iss(text);
    std::string word, result;
    while (iss >> word) {
        if (commonWords.find(word) == commonWords.end()) { // Keep the word if it's not common
            result += word + " ";
        }
    }
    return result;
}

// Function to calculate word frequencies
std::unordered_map<std::string, int> calculateWordFrequencies(const std::string &text) {
    std::unordered_map<std::string, int> wordCount;
    std::istringstream iss(text);
    std::string word;
    while (iss >> word) {
        wordCount[word]++;
    }
    return wordCount;
}

// Function to find top N frequent words
std::vector<std::pair<std::string, int>> findTopNWords(const std::unordered_map<std::string, int> &wordCount, int N) {
    std::vector<std::pair<std::string, int>> freqWords(wordCount.begin(), wordCount.end());
    std::sort(freqWords.begin(), freqWords.end(), [](const auto &a, const auto &b) {
        return a.second > b.second; // Sort by frequency in descending order
    });
    if (freqWords.size() > N) {
        freqWords.resize(N); // Keep only the top N words
    }
    return freqWords;
}

int main() {
    // Set of common words to be removed
    std::set<std::string> commonWords = {"A", "AND", "AN", "OF", "IN", "THE"};

    // List of all file paths
    std::vector<std::string> filePaths = {

    "C:\\Users\\AJEYA\\Documents\\Tag\\Cats by Moncrif.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Foxes Book of Martyrs Part 1.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Foxes Book of Martyrs Part 2.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Foxes Book of Martyrs Part 3.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Foxes Book of Martyrs Part 4.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Foxes Book of Martyrs Part 5.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Foxes Book of Martyrs Part 6.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Gerards Herbal Vol. 1.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Gerards Herbal Vol. 2.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Gerard's Herbal Vol. 3.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Gerards Herbal Vol.4.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Gil Blas.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Gossip in a Library.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Hudibras.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\King of the Beggars.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Knocknagow.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Les Chats par Moncrif.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Lives and Anecdotes of Misers.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Love and Madness - Herbert Croft.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Memoirs of Laetitia Pilkington V 1.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Memoirs of Laetitia Pilkington V 2.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Memoirs of Laetitia Pilkington V 3.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Memoirs of Mrs Margaret Leeson - Peg Plunkett.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Monro his Expedition.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Mrs Beetons Book of Household Management.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Out of the Hurly-Burly.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Percys Reliques.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Pompey The Little.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Radical Pamphlets from the English Civil War.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\Scepsis Scientifica.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Anatomy of Melancholy Part 1.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Anatomy of Melancholy Part 2.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Anatomy of Melancholy Part 3.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Complete Cony-catching.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Consolation of Philosophy.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Covent Garden Calendar.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Devil on Two Sticks.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Diary of a Lover of Literature.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The History Of Ireland - Geoffrey Keating.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The History of the Human Heart.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Ingoldsby Legends.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Life of Beau Nash.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Life of John Buncle by Thomas Amory.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Life of King Richard III.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Life of Pico della Mirandola.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Martyrdom of Man.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Masterpiece of Aristotle.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Memoirs of Count Boruwlaski.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Metamorphosis of Ajax.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Newgate Calendar - Supplement 3.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Newgate Calendar Supplement 2.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Newgate Calendar Supplement.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Newgate Calendar V 1.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Newgate Calendar V 2.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Newgate Calendar V 3.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Newgate Calendar V 4.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Newgate Calendar V 5.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Newgate Calendar V 6.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Poems of Ossian.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Poetical Works of John Skelton.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Protestant Reformation.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Real Story of John Carteret Pilkington.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Rowley Poems.txt",
    "C:\\Users\\AJEYA\\Documents\\Tag\\The Silver Fox.txt"


    };

    // Process each file
    for (const std::string &filePath : filePaths) {
        std::ifstream file(filePath);
        if (!file.is_open()) {
            std::cerr << "Error: Could not open the file " << filePath << std::endl;
            continue; // Skip this file if there's an error
        }

        std::ostringstream buffer;
        buffer << file.rdbuf(); // Read file content into a string stream
        std::string text = buffer.str();

        // Step 1: Clean and normalize the text
        text = cleanText(text);

        // Step 2: Remove common words
        text = removeCommonWords(text, commonWords);

        // Step 3: Calculate word frequencies for this file
        auto wordFrequencies = calculateWordFrequencies(text);

        // Step 4: Find top 100 frequent words for this file
        auto topWords = findTopNWords(wordFrequencies, 100);

        // Output the top 100 frequent words for this file
        std::cout << "Top 100 frequent words for file: " << filePath << std::endl;
        for (const auto &word : topWords) {
            std::cout << word.first << ": " << word.second << std::endl;
        }

        std::cout << "--------------------------------------" << std::endl;
    }

    return 0;
}

